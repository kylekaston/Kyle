#' @title kernal calculation
#'
#' @description contain the function distant, with samples:theta calculate kernel with element of columns
#' @description used in psvgd and svgd
#'
#' @param theta samples
#' @param h defined h in kernel function in the paper(-1 remained as the initial defination, and h is needed to change at some time)
#'
#' @return a list containing kernel and gradient kernal in matrix form
#' @export
#'
kernel=function(theta,h=-1){
  dist=distant(theta)
  if(h<0){
    h=median(dist)
    h=sqrt(0.5*h/log(nrow(theta)+1))
  }
  Kxy=exp(-dist/h)
  dxkxy=-Kxy%*%theta
  sumkxy=apply(Kxy,2,sum)
  for(i in seq(ncol(theta))){
    dxkxy[,i]=dxkxy[,i]+theta[,i]*sumkxy
  }
  dxkxy=dxkxy/(h^2)
  return(list(Kxy,dxkxy))
}
