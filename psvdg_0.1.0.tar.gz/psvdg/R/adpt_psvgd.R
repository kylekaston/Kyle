#' @title Projected Stein Variational Gradient Descent
#'
#' @description improved algorithm decreases the dimension by vertical projection, fastens the psgd
#' @description adpt.psvgd and adpt_psvgd, names are not identical, notice it cause there is prohibition to name an pscript with"." in file names
#' @param y the goal of the parameter(fixed)
#' @param x0 initial samples need to be sent to the goal distribution
#' @param f gradient of lnpdf(ln of pdf), please input a function (name)
#' @param lxmax iteration maximum control each iteration in adpt.psvgd
#' @param lwmax iteration maximum contrl each iteration in psgd
#' @param r phi(eigenvectors' dimension taken into use)
#' @param xtol adpt.psvgd convergence control criterion
#' @param wtol psvgd convergence control criterion
#'
#' @return final(goal) sample after iteration
#'
adpt_psvgd <- function(y,x0,f,lxmax,lwmax,r,xtol=1e-3,wtol=1e-3){
  lx = 0
  x = x0
  nrx = nrow(x)
  ncx = ncol(x)
  xold = 2*x
  dist = 1
  hesse = diag(x=0,ncol = nrx,nrow = nrx)
  while(lx<lxmax){
    d=diter(xold-x)
    if(lx%%10==0){
      if(d<xtol) break
    }
    xold = x
    hs=f(y,x)
    hesse=t(hs)%*%hs
    hesse = hesse/ncx
    eigen <- eigen(hesse)
    phi = eigen$vector[,1:r]
    x <- psvgd(y=y,x0=x,phir=phi,lnprob=f,n_iter=lwmax,wtol=wtol)
    lx <- lx+1
  }
  return(x)
}
