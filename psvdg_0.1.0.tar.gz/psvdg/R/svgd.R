#' @title Stein Variational Gradient Descent
#'
#' @description just as the name, svgn algorithm, more information in detail, reference to article SVGD
#' @param y the goal of the parameter(fixed)
#' @param x0 initial samples need to be sent to the goal distribution
#' @param lnprob the gradient of ln probability density (function name, function need to be defined by yourself or the high dimension gauss/normal distribution displayed here)
#' @param n_iter iteration control,usually much larger than adpt.psvgd for svgd is part of an inner iteraion of adpt.psvgd
#' @param stepsize stepsize in each iteration
#' @param alpha parameter in calculation
#' @param dtol covergence control criterion
#'
#' @return sample x0 after iteraion
#'
svgd=function(y,x0,lnprob,n_iter=1000,stepsize=1e-3,bandwidth=-1,alpha=0.9,dtol=1e-3){
  theta=x0
  thetaold=2*x0
  fudge_factor=1e-6
  historical_grad=0
  for(iter in 1:n_iter){
    if(iter%%100==0){
      d=diter(theta-thetaold)
      if(d<dtol) break
      thetaold=theta
    }
    lnpgrad=lnprob(y,theta)
    A=kernel(theta,h=-1)
    Kxy=A[[1]];dxkxy=A[[2]]
    grad_theta=(Kxy%*%lnpgrad+dxkxy)/nrow(x0)
    if(iter==0) historical_grad=historical_grad+grad_theta^2
    else historical_grad=alpha*historical_grad+(1-alpha)*(grad_theta^2)
    adj_grad=grad_theta/(fudge_factor+historical_grad^0.5)
    theta=theta+stepsize*adj_grad
  }
  return(theta)
}
